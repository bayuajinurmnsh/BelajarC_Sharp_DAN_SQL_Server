using FinalProjectCSharp.Configuration;

namespace FinalProjectCSharp.Models.DTOs.Responses
{
    public class JsonResponse : ResponseJson
    {

    }
}